גיא פירשט 322372681

רועי דוידוביץ 322718388


we have an input folder called www, 
we've added a compressed version of it for you to unzip to c:/temp 
(like written in the instructions manual)..